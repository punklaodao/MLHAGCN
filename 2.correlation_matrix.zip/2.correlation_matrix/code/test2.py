import numpy as np

MD = np.array([[1, 0, 1, 0, 1],
               [0, 1, 0, 0, 0],
               [1, 0, 0, 1, 1]])
occur_d = np.zeros(shape=(5, 5), dtype=float)
for i in range(5):
    for j in range(5):
        occur_d[i][j] = np.dot(MD[:, i], MD[:, j])
print(occur_d)
# [[2. 0. 1. 1. 2.]
#  [0. 1. 0. 0. 0.]
#  [1. 0. 1. 0. 1.]
#  [1. 0. 0. 1. 1.]
#  [2. 0. 1. 1. 2.]]

N_d = np.zeros(shape=(5, 1))
print(N_d)
# [[0.]
#  [0.]
#  [0.]
#  [0.]
#  [0.]]
print(np.sum(MD, axis=0))
# [2 1 1 1 2]
for i in range(5):
    N_d[i][0] = np.sum(MD, axis=0)[i]
print(N_d)
# [[2.]
#  [1.]
#  [1.]
#  [1.]
#  [2.]]
P_d = occur_d / N_d
print(P_d)
# [[1.  0.  0.5 0.5 1. ]
#  [0.  1.  0.  0.  0. ]
#  [1.  0.  1.  0.  1. ]
#  [1.  0.  0.  1.  1. ]
#  [1.  0.  0.5 0.5 1. ]]
