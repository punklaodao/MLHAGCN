import numpy as np
import pandas as pd
from scipy.sparse import coo_matrix


# # 1. lncRNA-lncRNA相似性
# l_l = pd.read_csv("../data/6.lncRNA-lncRNA.csv", sep=",", index_col=0)
# print(l_l)
# #             L1        L2        L3  ...      L828      L829      L830
# # L1    1.000000  0.191724  0.142505  ...  0.180233  0.185777  0.167826
# # L2    0.191724  1.000000  0.110010  ...  0.142147  0.209256  0.178563
# # L3    0.142505  0.110010  1.000000  ...  0.056463  0.116891  0.085950
# # L444  0.171243  0.153662  0.133788  ...  0.483840  0.311033  0.726832
# # L445  0.524540  0.325532  0.104834  ...  0.367301  0.406651  0.191061
# # ...        ...       ...       ...  ...       ...       ...       ...
# # L786  0.193034  0.599238  0.147513  ...  0.157198  0.183628  0.185011
# # L769  0.228987  0.563589  0.143414  ...  0.294207  0.417263  0.540637
# # L828  0.180233  0.142147  0.056463  ...  1.000000  0.604946  0.571804
# # L829  0.185777  0.209256  0.116891  ...  0.604946  1.000000  0.531648
# # L830  0.167826  0.178563  0.085950  ...  0.571804  0.531648  1.000000
# #
# # [861 rows x 861 columns]
#
# l_l = np.array(l_l)
# print(l_l)
# # [[1.         0.19172431 0.14250462 ... 0.18023341 0.18577742 0.16782634]
# #  [0.19172431 1.         0.11001036 ... 0.14214723 0.20925581 0.1785626 ]
# #  [0.14250462 0.11001036 1.         ... 0.05646317 0.11689097 0.08594972]
# #  ...
# #  [0.18023341 0.14214723 0.05646317 ... 1.         0.60494626 0.57180439]
# #  [0.18577742 0.20925581 0.11689097 ... 0.60494626 1.         0.53164804]
# #  [0.16782634 0.1785626  0.08594972 ... 0.57180439 0.53164804 1.        ]]
# print(l_l.shape, type(l_l))
# # (861, 861) <class 'numpy.ndarray'>
#
# index_l = pd.read_csv("../data/The number of the name_lncRNA.csv", sep=",")
# print(index_l)
# #            Name  Number Label
# # 0           21A       0    L1
# # 1           91H       1    L2
# # 2         AATBC       2    L3
# # 3      AB019562     443  L444
# # 4      AB073614     444  L445
# # ..          ...     ...   ...
# # 856        sONE     785  L786
# # 857        snaR     768  L769
# # 858      uc.338     827  L828
# # 859    uc001lsz     828  L829
# # 860  uc002mbe.2     829  L830
# #
# # [861 rows x 3 columns]
#
# index_l_num = list(index_l["Number"])
# print(index_l_num)
# # [0, 1, 2, 443, 444, 445, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, ...]
#
# # ll_sim = np.zeros(shape=(861, 861))
# # print(ll_sim, ll_sim.shape)
#
# row_index, col_index, data = [], [], []
# m = 0
# for row in index_l_num:        # [0, 1, 2, 443, 444, 445, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, ...]
#     n = 0
#     for col in index_l_num:    # [0, 1, 2, 443, 444, 445, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, ...]
#         row_index.append(row)
#         col_index.append(col)
#         data.append(l_l[m][n])
#         n += 1
#     m += 1
# print(data)
#
# row_index = np.array(row_index)
# col_index = np.array(col_index)
# data = np.array(data)
#
# l_l_sim = coo_matrix((data, (row_index, col_index)), shape=(861, 861))
# print(l_l_sim)
# l_l_sim = l_l_sim.toarray()
# print(l_l_sim)
# print(l_l_sim.shape)
#
# np.save("l_l_sim", l_l_sim)


# 2. disease-disease相似性
d_d = pd.read_csv("../data/4.disease-disease.csv", sep=",", index_col=0)
print(d_d)
#            D88      D104        D6  ...      D249      D250      D251
# D88   1.000000  0.488372  0.114286  ...  0.206478  0.217742  0.310345
# D104  0.488372  1.000000  0.057325  ...  0.032028  0.148936  0.112782
# D6    0.114286  0.057325  1.000000  ...  0.056106  0.059211  0.083333
# D11   0.070423  0.018868  0.176471  ...  0.016287  0.019481  0.041096
# D12   0.063158  0.024155  0.165138  ...  0.022333  0.024752  0.041237
# ...        ...       ...       ...  ...       ...       ...       ...
# D243  0.472973  0.145455  0.056818  ...  0.047022  0.071875  0.118421
# D247  0.076923  0.028902  0.195652  ...  0.026866  0.029762  0.050000
# D249  0.206478  0.032028  0.056106  ...  1.000000  0.033210  0.105882
# D250  0.217742  0.148936  0.059211  ...  0.033210  1.000000  0.117188
# D251  0.310345  0.112782  0.083333  ...  0.105882  0.117188  1.000000

d_d = np.array(d_d)
k = len(d_d)     # 432
print("len(d_d): ", k)
index_d = pd.read_csv("../data/The number of the name_disease.csv", sep=",")
index_d = list((index_d["Label_number"]) - 1)
print(index_d)

row_index, col_index, data = [], [], []
m = 0
for row in index_d:
    n = 0
    for col in index_d:
        row_index.append(row)
        col_index.append(col)
        data.append(d_d[m][n])
        n += 1
    m += 1
row_index = np.array(row_index)
col_index = np.array(col_index)
data = np.array(data)

B = coo_matrix((data, (row_index, col_index)), shape=(k, k))
d_d_sim = B.toarray()
print(d_d_sim)
# [[1.         0.32038835 0.01212121 ... 0.         0.         0.        ]
#  [0.32038835 1.         0.26190476 ... 0.         0.         0.        ]
#  [0.01212121 0.26190476 1.         ... 0.         0.         0.        ]
#  ...
#  [0.         0.         0.         ... 1.         0.25714286 0.25714286]
#  [0.         0.         0.         ... 0.25714286 1.         0.42857143]
#  [0.         0.         0.         ... 0.25714286 0.42857143 1.        ]]
print(d_d_sim.shape)

print(d_d_sim[87][103])  # 0.488372093
print(d_d[0][1])         # 0.488372093

print(d_d_sim[5][103])   # 0.057324841
print(d_d[2][1])         # 0.057324841

np.save("d_d_sim", d_d_sim)