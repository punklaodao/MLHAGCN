import numpy as np
import torch

MD = np.load("../data/MD_matrix.npy")   # (861, 253)
label_num = MD.sum(axis=0)
print(label_num)
# np.save("label_sum", label_num)
print(label_num.shape)                  # (253,)

label = np.hstack((MD, np.zeros(shape=(861, 179))))
label_num_432 = label.sum(axis=0)
print("label_num_432", label_num_432)
print(label_num_432.shape)
for i in range(432):
    if label_num_432[i] == 0:
        label_num_432[i] = 1e-6
print(label_num_432)
np.save("label_sum_432", label_num_432)

print("-------------------------------------------------")
label_with_weight = label_num / label_num.sum()
print(label_with_weight)
print(label_with_weight.shape)
# np.save("label_weight", label_with_weight)


print("-------------------------------------------------")
label_num_2 = label_num
label_num_2[label_num < 10] = 0
print(label_num)
label_with_weight_2 = label_num_2 / label_num_2.sum()
print("label_with_weight_2")
print(label_with_weight_2)
print(label_with_weight_2.shape)
print(label_with_weight_2.sum())
# np.save("label_weight2", label_with_weight_2)
print("-------------------------------------------------")

weight = torch.tensor(label_with_weight)
print(weight)
print(weight.shape)
