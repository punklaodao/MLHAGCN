import numpy as np
import pandas as pd

# 读取存放lncRNA miRNA disease节点 name id label的文件
d_name_num_label = pd.read_csv("../data/The number of the name_disease.csv", sep=",")   # ,作为分隔符
print(d_name_num_label)
m_name_num_label = pd.read_csv("../data/The number of the name_miRNA.csv", sep=",")
print(m_name_num_label)
l_name_num_label = pd.read_csv("../data/The number of the name_lncRNA.csv", sep=",")
print(l_name_num_label)
#            Name  Number Label
# 0           21A       0    L1
# 1           91H       1    L2
# 2         AATBC       2    L3
# 3      AB019562     443  L444
# 4      AB073614     444  L445
# ..          ...     ...   ...
# 856        sONE     785  L786
# 857        snaR     768  L769
# 858      uc.338     827  L828
# 859    uc001lsz     828  L829
# 860  uc002mbe.2     829  L830


#
# name = list(name_id_label['Name'])           # ['21A', '91H', 'AATBC', 'ABHD11-AS1', 'Abhd11os',...]
# id = list(name_id_label['Number'])           # [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, ...]
# label = list(name_id_label['Label'])         # ['L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'L7',...]
#

# # 名称与id、label转换
# # 定义 lncRNA、miRNA、疾病名称 --》标签L、M、D + id
# # 定义 标签L、M、D + id       --》lncRNA、miRNA、疾病名称
# def name2id(names):
#     n = 0
#     name2id_dict = {}
#     for name in names:
#         name2id_dict[name] = {}
#         n += 1
#     return name2id_dict
#
# lnc2id = name2id()