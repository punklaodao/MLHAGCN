import numpy as np
import pandas as pd

name_num_label = pd.read_csv("../data/The number of the name.csv", sep=",")
#                       Name  Number  Node_number Label
# 0                      21A       0            1    L1
# 1                      91H       1            2    L2
# 2                    AATBC       2            3    L3
# 3               ABHD11-AS1       3            4    L4
# 4                 Abhd11os       4            5    L5
# ...                    ...     ...          ...   ...
# 1725      Vulvar Neoplasms    1725          428  D428
# 1726  Periodontal Diseases    1726          429  D429
# 1727   Peritoneal Fibrosis    1727          430  D430
# 1728               Gliosis    1728          431  D431
# 1729             Emphysema    1729          432  D432
#
# [1730 rows x 4 columns]

num_label = {}
node_number = {}
n = 0
for number in name_num_label["Number"]:
    num_label[number] = name_num_label["Label"][n]
    node_number[number] = name_num_label["Node_number"][n]
    n += 1


# 将节点的number转换成对应的标签号
def num2label(num):
    return num_label[num]


def num2node_number(num):
    return node_number[num]


def label2num(label):
    pass


# print(num2label(1299))  # D2
# print(num2label(860))   # L861
# print(num2label(900))   # M40
# print(num2node_number(1299))   # 2
# print(num2node_number(860))   # 861
# print(num2node_number(900))   # 40
