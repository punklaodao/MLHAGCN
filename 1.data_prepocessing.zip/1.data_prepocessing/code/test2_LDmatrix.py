import scipy.sparse as sp
import numpy as np
import pandas as pd
from utils import *
from scipy.sparse import coo_matrix


# 在lncRNA-disease关联文件中
# lncRNA节点数：861   疾病节点数：253   l-d关联数：4518
# lncRNA节点编号0~860 疾病节点编号1298~1550
l_d = pd.read_csv("../data/1.lncRNA-disease.csv", sep=",", header=None)
print(l_d)
#               0                           1    2     3
# 0           21A                 Astrocytoma    0  1298
# 1           21A                   Neoplasms    0  1299
# 2           21A  Uterine Cervical Neoplasms    0  1300
# 3           21A                Glioblastoma    0  1301
# 4           21A               Neuroblastoma    0  1302
# ...         ...                         ...  ...   ...
# 4513  ZNRD1-AS1       Endometrial Neoplasms  858  1362
# 4514  ZNRD1-AS1              Lung Neoplasms  858  1308
# 4515       ZXF1      Adenocarcinoma of Lung  859  1329
# 4516       ZXF2           Stomach Neoplasms  860  1307
# 4517       ZXF2      Adenocarcinoma of Lung  860  1329

# 行号 -> lncRNA节点的编号可以直接作为行号
row = np.array(l_d[2])                  # [  0   0   0 ... 859 860 860]  row.shape -> (4518,)

# 列号 -> 编号-疾病节点编号-矩阵坐标索引
col = []
for d in l_d[3]:
    col.append(num2node_number(d))
col = np.array(col) - 1                 # [ 0  1  2 ... 31  9 31]        col.shape -> (4518,)

# 值 数据类型为int!!!
data = np.ones(shape=len(l_d), dtype=int)          # [1. 1. 1. ... 1. 1. 1.]         data.shape -> (4518,)

MD = coo_matrix((data, (row, col)), shape=(861, 253))
print(MD)
#   (0, 0)	1.0
#   (0, 1)	1.0
#   (0, 2)	1.0
#   (0, 3)	1.0
#   (0, 4)	1.0
#   (1, 5)	1.0
#   (1, 6)	1.0
#   (1, 7)	1.0
#   (2, 8)	1.0
# ...
#   (857, 6)	1.0
#   (857, 9)	1.0
#   (857, 12)	1.0
#   (858, 64)	1.0
#   (858, 10)	1.0
#   (859, 31)	1.0
#   (860, 9)	1.0
#   (860, 31)	1.0
MD_array = MD.toarray()
print(MD_array)
# [[1 1 1 ... 0 0 0]
#  [0 0 0 ... 0 0 0]
#  [0 0 0 ... 0 0 0]
#  ...
#  [0 0 0 ... 0 0 0]
#  [0 0 0 ... 0 0 0]
#  [0 0 0 ... 0 0 0]]

print(type(MD_array))
print(MD_array.shape)    # (861, 253)


np.save("MD_matrix", MD_array)
