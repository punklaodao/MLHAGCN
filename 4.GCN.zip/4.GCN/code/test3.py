from sklearn.metrics import precision_score, recall_score,f1_score, accuracy_score
import numpy as np

label = np.array([[1, 1, 0, 0],
                  [1, 0, 1, 0],
                  [0, 1, 0, 1]])
pred = np.array([[1, 1, 0, 0],
                 [1, 1, 1, 0],
                 [1, 1, 0, 1]])

print(label)
print(pred)

accuracy0 = accuracy_score(y_true=label, y_pred=pred)                            # 计算完全匹配率

# accuracy1 = average_precision_score(y_true=label, y_score=pred, average="micro") # Compute average precision (AP) from prediction scores
precision1 = precision_score(y_true=label, y_pred=pred, average="micro")
recall1 = recall_score(y_true=label, y_pred=pred, average="micro")
f1score1 = f1_score(y_true=label, y_pred=pred, average="micro")

# accuracy2 = average_precision_score(y_true=label, y_score=pred, average="macro")
precision2 = precision_score(y_true=label, y_pred=pred, average="macro")
recall2 = recall_score(y_true=label, y_pred=pred, average="macro")
f1score2 = f1_score(y_true=label, y_pred=pred, average="macro")

# accuracy3 = average_precision_score(y_true=label, y_score=pred, average="samples")
precision3 = precision_score(y_true=label, y_pred=pred, average="samples")
recall3 = recall_score(y_true=label, y_pred=pred, average="samples")
f1score3 = f1_score(y_true=label, y_pred=pred, average="samples")

# print(accuracy1)  # 0.75
# print(accuracy2)  # 0.8333333333333333
# print(accuracy3)  # 0.7777777777777777
print(precision1, recall1, f1score1)
print(precision2, recall2, f1score2)
print(precision3, recall3, f1score3)
