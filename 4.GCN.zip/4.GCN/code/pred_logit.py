import numpy as np
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from util import *
from sklearn.utils.multiclass import type_of_target
from sklearn.preprocessing import MultiLabelBinarizer

embedding_dim = 512
weight = 0.8
threshold = 0.5

label = np.load("../data/MD_matrix.npy")
label = np.array(label, dtype=int)
output = np.load("../results_432/MLNVGCN_output_{}_{}_{}.npy".format(embedding_dim, weight, threshold))
pred = np.load("../results_432/MLNVGCN_prediction_{}_{}_{}.npy".format(embedding_dim, weight, threshold))

# l = []
# for i in range(label.shape[0]):
#     for j in range(label.shape[1]):
#         if label[i][j] not in {0, 1}:
#             print(i, j)                # 75,21
#             l.append(label[i][j])
# print(l)   # 2

# label[75][12] = 1

print(type_of_target(label))   # multiclass-multioutput
print(type_of_target(pred))    # multilabel-indicator



print(label.shape, output.shape)   # (861, 253) (861, 253)
print(label)
print(output)

print(type_of_target(label))   # multiclass-multioutput
print(type_of_target(pred))    # multilabel-indicator

#
# print("不与任何疾病关联的lncRNA:")
# for i in range(label.shape[0]):
#     if label[i].sum() == 0:
#         print(i)
# print("不与任何lncRNA关联的疾病：")
# for j in range(label.shape[1]):
#     if label[:, j].sum() == 0:
#         print(j)

# 基于排序的评估指标
print(One_error(label, logit=output))      # 0.017421602787456445
print(Coverage(logit=output, label=label))   # 21.50871080139373
print(RankingLoss(label=label, logit=output))  # 0.014865931911890515
print(Average_Precision(label=label, logit=output))  # 0.9241790129930967

# 基于标签的评估指标
# 1) macro
macro_accuracy, _, _, _ = macro_matrix(label, pred)
macro_precision = precision_score(y_true=label, y_pred=pred, average="macro")
macro_recall = recall_score(y_true=label, y_pred=pred, average="macro")
macro_f1 = f1_score(y_true=label, y_pred=pred, average="macro")

print("macro_accuracy: ", macro_accuracy)
print("macro_precision: ", macro_precision)
print("macro_recall", macro_recall)
print("macro_f1: ", macro_f1)


# 使用sklearn metric计算的结果：
# macro_accuracy:  0.9926572825696387
# macro_precision:  0.9607818134647342
# macro_recall 0.8992192441223645
# macro_f1:  0.921791522602885

# 自定义计算的结果 （很多标签的FP+TP==0 TP+FN==0）
# macro_accuracy:  0.9942387057975605
# macro_precision:  0.3060725182464914
# macro_recall 0.21937608412850168
# macro_f1:  0.21940845158711764

# 2) micro
micro_accuracy, micro_precision, micro_recall, micro_f1 = micro_matrix(label, pred)
micro_precision_sk = precision_score(y_true=label, y_pred=pred, average="micro")
micro_recall_sk = precision_score(y_true=label, y_pred=pred, average="micro")
micro_f1_sk = precision_score(y_true=label, y_pred=pred, average="micro")
print("micro_accuracy: ", micro_accuracy)
print("micro_precision: ", micro_precision)
print("micro_recall", micro_recall)
print("micro_f1: ", micro_f1)
# micro_accuracy:  0.9942387057975605
# micro_precision:  0.9429502852485737
# micro_recall 0.7686005314437555
# micro_f1:  0.8468952055630109


np.save("MD_matrix", label)