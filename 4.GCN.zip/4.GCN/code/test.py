import numpy as np
import torch
from torch import nn
from sklearn.metrics import accuracy_score, zero_one_loss, precision_score, recall_score, f1_score, hamming_loss
from model import GCNwithNode2Vec
from util import *

labels_l, features_l, adj_d, inp_d, idx_train_l, idx_test_l = load_data("lncRNA")
print(labels_l)
print(labels_l.shape)
print(labels_l[idx_train_l])
print(labels_l[idx_train_l].shape)

model = GCNwithNode2Vec(num_classes=432, in_features=128, adj=adj_d)
out = model(features_l, inp_d)

print(out)
print(out.shape)       # torch.Size([861, 432])

# criterion = nn.BCEWithLogitsLoss()
# train_loss = criterion(out[idx_train_l], labels_l[idx_train_l])
# print(train_loss)      # tensor(0.7352, grad_fn=<BinaryCrossEntropyWithLogitsBackward>)
# print(train_loss.shape)


# out_numpy = out.detach().numpy()
# print(out_numpy)
# print(out_numpy.shape)
# print(out_numpy[idx_train_l])
# print(out_numpy[idx_train_l].shape)

y_true = labels_l[idx_train_l].detach().numpy()
# y_pred = out_numpy[idx_train_l]
print(y_true.shape)
# print(y_pred.shape)
# train_precision = precision_score(y_true=y_true, y_pred=y_pred, average="samples")
# print(train_precision)


def output2label(output, x, y):
    label = torch.where(output >= 0.5, x, y)
    return label


def Accuracy(y_true, y_pred):
    count = 0
    for i in range(y_true.shape[0]):
        p = sum(np.logical_and(y_true[i], y_pred[i]))  # 逻辑与   得到每个样本的TP的标签数逻辑或   得到每个样本的 预测为正 或 真实为正 的标签数(TP+FN+F
        q = sum(np.logical_or(y_true[i], y_pred[i]))  # P)
        count += p / q  # 计算当前样本的准确率
    return count / y_true.shape[0]  # 返回所有样本上的均值


x = torch.ones(size=labels_l.size(), dtype=torch.int32)     # output值 >= 0.5，预测结果为 1，表示有关联
y = torch.zeros(size=labels_l.size(), dtype=torch.int32)    # output值 < 0.5，预测结果为 0，表示无关联

y_pred = output2label(out, x, y)
y_pred = y_pred[idx_train_l].detach().numpy()
print(y_pred)
print(y_pred.shape)

print(Accuracy(y_true, y_pred))



def ml_Hamming_Loss(y_true, y_pred):
    count = 0
    p = y_true.shape[1]
    for i in range(y_true.shape[0]):                # p为标签集的大小
        q = torch.sum(torch.tensor(y_true[i] == y_pred[i], dtype=torch.int32))       # q为该样本正确预测的标签的数量（TP+TN）
        count += p - q                                     # count为该样本错误预测的标签的数量
    return count / (y_true.shape[0] * y_true.shape[-1])


y_true = torch.tensor([[1, 1, 0, 0, 1],
                       [0, 1, 0, 1, 0],
                       [1, 0, 1, 0, 1]])

y_pred = torch.tensor([[1, 1, 1, 0, 1],
                       [0, 0, 1, 1, 0],
                       [1, 1, 1, 0, 0]])
print(y_true[0] == y_pred[0])
print(torch.tensor(y_true[0] == y_pred[0], dtype=torch.int32))
print(ml_Hamming_Loss(y_true, y_pred))

