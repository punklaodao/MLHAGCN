import numpy as np

N = 861
idx = np.arange(N)  # 返回长度为N的列表，起点为0，终点为N-1
np.random.shuffle(idx)
print(idx)

for i in range(5):
    print("Fold {}".format(i + 1))
    idx_test = idx[i * N // 5:(i + 1) * N // 5]
    print(idx_test)
    print(idx_test.shape)

    idx_train = np.delete(idx, idx_test)
    print("idx_train", idx_train)
    print(idx_train.shape)

a = np.array([0, 3, 2, 1])
b = np.array([[0, 0, 0, 0],
              [1, 1, 1, 1],
              [2, 2, 2, 2],
              [3, 3, 3, 3]])
print(b[a])
# [[0 0 0 0]
#  [3 3 3 3]
#  [2 2 2 2]
#  [1 1 1 1]]
print(b[a][1])
# [3 3 3 3]
