import argparse
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, zero_one_loss, precision_score, recall_score, f1_score, hamming_loss, \
    roc_auc_score

from util import *
from model import GCNwithNode2Vec


"""
对lncRNA分类，类别数为432, 样本数为861，标签形状为(861, 432)
训练集大小 int(861*0.8)=689
验证集大小 int(861*0.2)=172

训练GCN分类器，图中节点为疾病节点。
GCN的输入 节点特征x 形状为(253, input_size)
         邻接矩阵adj 形状为(253, 253)
"""

parser = argparse.ArgumentParser()
parser.add_argument('--no_cuda', action='store_true', default=False, help="Disables CUDA training.")
# parser.add_argument('--fastmode', action='store_true', default=False, help="Validata during training pass.")
parser.add_argument('--seed', type=int, default=72, help="Random seed.")
parser.add_argument('--epochs', type=int, default=300, help="Number of epochs to train.")
parser.add_argument('--lr', type=float, default=0.005, help="Initial learning rate.")
parser.add_argument('--weight_decay', type=float, default=5e-4, help="Weight decay (L2 loss on parameters).")
parser.add_argument('--dropout', type=float, default=0.7, help='Dropout rate (1 - keep probability).')
# parser.add_argument('--alpha', type=float, default=0.2, help='Alpha for the leaky_relu.')
parser.add_argument('--embedding_dim', type=int, default=512, help="Embedding dimensions of node2vec.")
parser.add_argument('--t', type=int, default=0.8, help="The weight t between correlation and similarity matirx.")
parser.add_argument('--a', type=int, default=0.5, help="The threshold a to binary adj")
# parser.add_argument('--nclass_d', type=int, default=240, help="Number of classes of diseases.")
# parser.add_argument('--nclass_l', type=int, default=432, help="Number of classes of lncRNAs.")

args = parser.parse_args()
args.cuda = not args.no_cuda and torch.cuda.is_available()

# 设置随机数种子
random.seed(args.seed)
np.random.seed(args.seed)
torch.manual_seed(args.seed)
if args.cuda:
    torch.cuda.manual_seed(args.seed)

# 加载数据
labels_l, features_l, adj_d, inp_d, _, _ = load_data_432("lncRNA", args.t)
# 形状
# labels_l     -> torch.Size([861, 432])  !
# features_l   -> torch.Size([861, 128])
# adj_d        -> torch.Size([432, 432])  !
# inp_d        -> torch.Size([432, 128])  !
# idx_train_l  -> torch.Size([688])
# idx_test_l   -> torch.Size([173])

label_weight = 0.1 * np.load("../data/label_sum_432.npy")
label_weight = torch.tensor(label_weight)

# 定义模型
model = GCNwithNode2Vec(num_classes=432, in_features=512, adj=adj_d, a=args.a)
# 定义优化器
optimizer = torch.optim.Adam(params=model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
# 定义损失函数
criterion = nn.MultiLabelSoftMarginLoss(weight=label_weight)

# 计算准确率的两个tensor张量
x = torch.ones(size=labels_l.size(), dtype=torch.int32)     # output值 >= 0.5，预测结果为 1，表示有关联
y = torch.zeros(size=labels_l.size(), dtype=torch.int32)    # output值 < 0.5，预测结果为 0，表示无关联


# 定义训练函数
def train(epoch, inp_d, features_l, labels_l, x, y, idx_train_l, idx_test_l):
    if args.cuda:
        model.cuda()
        # adj_d = adj_d.cuda()                      # GCN分类器的输入：adj
        inp_d = inp_d.cuda()
        features_l = features_l.cuda()  # 对lncRNA进行分类时使用的 lncRNA 的特征向量
        labels_l = labels_l.int().cuda()
        idx_train_l = idx_train_l.cuda()  # idx_train_l 是tensor类型的张量 且在cuda上
        idx_test_l = idx_test_l.cuda()

        criterion.cuda()

        x = x.cuda()
        y = y.cuda()

    t = time.time()
    model.train()
    optimizer.zero_grad()
    output = model(features_l, inp_d)          # 形状：torch.Size([861, 432])
    train_loss = criterion(output[idx_train_l], labels_l[idx_train_l])   # loss是一个标量
    train_loss.backward()
    optimizer.step()

    # 评估指标
    train_acc = ml_accuracy(output[idx_train_l], labels_l[idx_train_l], x[idx_train_l], y[idx_train_l])
    # precision recall f1_score hamming_loss
    # 将label pred 索引 都转换为numpy数组

    y_pred = output2label(output, x, y)

    train_precision = ml_Precision(labels_l[idx_train_l], y_pred[idx_train_l])
    train_recall = ml_Recall(y_true=labels_l[idx_train_l], y_pred=y_pred[idx_train_l])
    train_f1 = ml_F1measure(y_true=labels_l[idx_train_l], y_pred=y_pred[idx_train_l])
    train_hamming = ml_Hamming_Loss(y_true=labels_l[idx_train_l], y_pred=y_pred[idx_train_l])
    train_subacc = ml_sub_accuracy(y_true=labels_l[idx_train_l], y_pred=y_pred[idx_train_l])

    # if not args.fastmode:
    #     model.eval()
    #     output = model(features_l, inp_d)

    # eval_loss = criterion(output[idx_test_l], labels_l[idx_test_l])
    # eval_acc = ml_accuracy(output[idx_test_l], labels_l[idx_test_l], x[idx_test_l], y[idx_test_l])

    y_pred = output2label(output, x, y)


    # val_precision = ml_Precision(y_true=labels_l[idx_test_l], y_pred=y_pred[idx_test_l])
    # val_recall = ml_Recall(y_true=labels_l[idx_test_l], y_pred=y_pred[idx_test_l])
    # val_f1 = ml_F1measure(y_true=labels_l[idx_test_l], y_pred=y_pred[idx_test_l])
    # val_hamming = ml_Hamming_Loss(y_true=labels_l[idx_test_l], y_pred=y_pred[idx_test_l])
    # val_subacc = ml_sub_accuracy(y_true=labels_l[idx_test_l], y_pred=y_pred[idx_test_l])

    print("Epoch: {:04d}".format(epoch + 1),
          "loss_train: {:.4f}".format(train_loss.item()),
          "acc_train: {:.4f}".format(train_acc.item()),
          "precision_train: {:.4f}".format(train_precision),
          "recall_train: {:.4f}".format(train_recall),
          "f1_train: {:.4f}".format(train_f1),
          "hamming_train: {:.4f}".format(train_hamming),
          "train_subacc: {:.4f}".format(train_subacc),

          # "loss_val: {:.4f}".format(eval_loss.item()),
          # "acc_val: {:.4f}".format(eval_acc.item()),
          # "precision_val: {:.4f}".format(val_precision),
          # "recall_val: {:.4f}".format(val_recall),
          # "f1_val: {:.4f}".format(val_f1),
          # "hamming_train: {:.4f}".format(val_hamming),
          # "val_subacc: {:.4f}".format(val_subacc),
          #
          "time: {:.4f}".format(time.time() - t))

    if epoch == args.epochs - 1:

        y_pred_binary = np.array(y_pred.cpu())
        output = output.detach().cpu().numpy()
        idx_train_l = np.array(idx_train_l.cpu())
        labels_l = np.array(labels_l.cpu())

        for j in range(432):
            auc_score[i][j] = roc_auc_score(y_true=labels_l[idx_train_l][j], y_score=output[j])
            acc[i] = accuracy_score(y_true=labels_l[idx_train_l][j], y_pred=y_pred_binary[j])
            precisin[i] = precision_score(y_true=labels_l[idx_train_l][j], y_pred=y_pred_binary[j])
            recall[i] = recall_score(y_true=labels_l[idx_train_l][j], y_pred=y_pred_binary[j])
            f1[i] = f1_score(y_true=labels_l[idx_train_l][j], y_pred=y_pred_binary[j])

        # np.save("../results_432/MLNVGCN_prediction_{}_{}_{}_fold{}".format(args.embedding_dim, args.t, args.a, i+1), y_pred_binary)
        # np.save("../results_432/MLNVGCN_output_{}_{}_{}_fold{}".format(args.embedding_dim, args.t, args.a, i+1), output)





# 训练模型
t_total = time.time()
N = 861
idx = np.arange(N)  # 返回长度为N的列表，起点为0，终点为N-1
np.random.shuffle(idx)

acc = np.zeros(shape=(5, 432))
precisin = np.zeros(shape=(5, 432))
recall = np.zeros(shape=(5, 432))
f1 = np.zeros(shape=(5, 432))
auc_score = np.zeros(shape=(5, 432))

for i in range(5):
    print("Fold {}".format(i + 1))
    idx_test = idx[i * N // 5:(i + 1) * N // 5]
    idx_train = np.delete(idx, idx_test)
    idx_train = torch.LongTensor(idx_train)
    idx_test = torch.LongTensor(idx_test)
    for epoch in range(args.epochs):
        train(epoch, inp_d, features_l, labels_l, x, y, idx_train, idx_test)
print(acc)
print(precisin)
print(recall)
print(f1)
print(auc_score)

np.save("acc_5fold", acc)
np.save("precisin_5fold", precisin)
np.save("recall_5fold", recall)
np.save("f1_5fold", f1)
np.save("acc_5fold", acc)
np.save("auc_score_5fold", auc_score)





# print(labels_l)
print("Optimization Finished!")
print("Total time elapsed: {:.4f}s".format(time.time() - t_total))
