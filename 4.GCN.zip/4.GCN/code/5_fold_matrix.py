import numpy as np
from sklearn.metrics import accuracy_score, zero_one_loss, precision_score, recall_score, f1_score, hamming_loss, \
    roc_curve, auc, precision_recall_curve, roc_auc_score

acc = np.zeros(shape=(5, 432))
precisin = np.zeros(shape=(5, 432))
recall = np.zeros(shape=(5, 432))
f1 = np.zeros(shape=(5, 432))
auc_score = np.zeros(shape=(5, 432))
for i in range(5):
    output = np.load("../results_432/MLNVGCN_output_512_0.8_0.5_fold{}.npy".format(i+1))
    pred = np.load("../results_432/MLNVGCN_prediction_512_0.8_0.5_fold{}.npy".format(i+1))
    label_all = np.load("MD_matrix.npy")
    n = output.shape[0]
    label_all = np.hstack((label_all, np.zeros(shape=(n, 179))))
    label = label_all[0:n+1]
    # acc = np.zeros(5)
    for j in range(432):
        auc_score[i][j] = roc_auc_score(y_true=label[j], y_score=output[j])
        acc[i] = accuracy_score(y_true=label[j], y_pred=label[j])
        precisin[i] = precision_score(y_true=label[j], y_pred=label[j])
        recall[i] = accuracy_score(y_true=label[j], y_pred=label[j])
        f1[i] = accuracy_score(y_true=label[j], y_pred=label[j])

print(auc_score)
print(auc_score.shape)          # (5, 432)
mean = auc_score.mean(axis=0)
print(mean.shape)               # (432,)
mean_all = mean.mean()
print(mean_all)