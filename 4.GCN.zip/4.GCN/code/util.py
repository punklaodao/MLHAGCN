import math
from urllib.request import urlretrieve
import torch
from PIL import Image
from tqdm import tqdm
import numpy as np
import random
import torch.nn.functional as F


"将模型输出的output转换为预测标签"
def output2label(output, x, y):
    label = torch.where(output >= 0.5, x, y)
    return label


"""对于融合相关性与相似性的邻接矩阵，根据阈值a转换为0-1二值矩阵，并处理GCN可能产生的过平滑问题"""
def gen_A(P, a):
    if P.shape == (432, 432):
        P[P < a] = 0  # 阈值t
        P[P >= a] = 1
        P = P * 0.25 / (P.sum(0, keepdims=True) + 1e-6)
        P = P + np.identity(432, np.int)  # 对角线元素置为1
        return P
    else:
        P[P < a] = 0                         # 阈值t
        P[P >= a] = 1
        P = P * 0.25 / (P.sum(0, keepdims=True) + 1e-6)
        P = P + np.identity(253, np.int)     # 对角线元素置为1
        return P


"""计算正则化的邻接矩阵，数据类型为tensor"""
def gen_adj(A):
    D = torch.pow(A.sum(1).float(), -0.5)             # A.sum(1) --> 求度
    D = torch.diag(D)                                 # 生成对角矩阵
    adj = torch.matmul(torch.matmul(A, D).t(), D)     # 三个矩阵相乘 D^(-1/2)AD^(-1/2)
    return adj


"""加载训练模型需要的参数"""
def load_data(task, t):
    embeddings = np.load("../data/node_embeddings/lmd_embedding_256_30.npy")
    label = np.load("../data/MD_matrix.npy")                        # 形状为(861, 253)
    # label = np.hstack((label, np.zeros(shape=(861, 179))))          # 形状为(861, 432)

    if task == "lncRNA":
        # 处理 GCN的输入——邻接矩阵 adj_d
        adj_d = np.load("../data/correlation_matrix/P_d4_{}.npy".format(t))    # 注意：这里直接使用融合相关性与相似性的
        # if adj_d.shape == (253, 253):
        #     adj_d = np.hstack((adj_d, np.zeros(shape=(253, 179))))
        #     adj_d = np.vstack((adj_d, np.zeros(shape=(179, 432))))
        print("adj_d.shape: ", adj_d.shape)  # (253, 253)

        # 处理 GCN的输入——节点特征向量 inp_d
        # embeddings_d = embeddings[1298:1730, :]  # 作为GCN分类器的输入x
        embeddings_d = embeddings[1298:1551, :]    # 作为GCN分类器的输入x
        print("embeddings_d.shape: ", embeddings_d.shape)           # (432, 128)   -> (253, 128)

        # 处理 需要进行分类的 lncRNA 节点的特征向量 feature_l
        embeddings_l = embeddings[0:861, :]  # 由node2vec算法获取的lncRNA节点的特征，用于对lncRNA分类
        feature_l = embeddings_l
        print("feature_l.shape:", feature_l.shape)           # (861, 128)

        # 处理 lncRNA 节点的标签
        label_l = label
        print(label_l.shape)  # (861, 432)

        # 处理训练集、测试集
        lncRNA_n = 861
        train_n = int(lncRNA_n * 0.8)        # 训练集长度：688    测试集长度：173
        idx_train_l = range(0, train_n)      # range(0, 688)
        idx_test_l = range(train_n, 861)     # range(688, 861)

        # 将上述数据转换为 tensor类型
        label_l = torch.Tensor(label_l)
        feature_l = torch.FloatTensor(feature_l)
        # adj_d = torch.FloatTensor(adj_d)  #
        inp_d = torch.FloatTensor(embeddings_d)
        idx_train_l = torch.LongTensor(idx_train_l)
        idx_test_l = torch.LongTensor(idx_test_l)

        print(label_l.shape, feature_l.shape, adj_d.shape, inp_d.shape, idx_train_l.shape, idx_test_l.shape)
        return label_l, feature_l, adj_d, inp_d, idx_train_l, idx_test_l

    else:
        # 对疾病节点进行分类
        # 处理 GCN的输入——邻接矩阵 adj_d
        adj_d = np.load("../data/correlation_matrix/P_d1.npy")    # 注意：
        if adj_d.shape == (253, 253):
            adj_d = np.hstack((adj_d, np.zeros(shape=(253, 179))))
            adj_d = np.vstack((adj_d, np.zeros(shape=(179, 432))))
        print("adj_d.shape:", adj_d.shape)  # (432, 432)

        # 处理 GCN的输入——节点特征向量 inp_d
        embeddings_d = embeddings[1298:1730, :]  # 作为GCN分类器的输入x
        print(embeddings_d.shape)           # (432, 128)

        # 处理 需要进行分类的 lncRNA 节点的特征向量 feature_l
        embeddings_l = embeddings[0:861, :]  # 由node2vec算法获取的lncRNA节点的特征，用于对lncRNA分类
        feature_l = embeddings_l
        print("feature_l.shape:", feature_l.shape)           # (861, 128)

        # 处理 lncRNA 节点的标签
        label_l = label
        print(label_l.shape)  # (861, 432)

        # 处理训练集、测试集
        lncRNA_n = 861
        train_n = int(lncRNA_n * 0.8)        # 训练集长度：688    测试集长度：173
        idx_train_l = range(0, train_n)      # range(0, 688)
        idx_test_l = range(train_n, 861)     # range(688, 861)

        # 将上述数据转换为 tensor类型
        label_l = torch.FloatTensor(label_l)
        features_l = torch.FloatTensor(feature_l)
        adj_d = torch.FloatTensor(adj_d)  # 原adj_l为(240, 240)的 numpy.ndarray
        idx_train_l = torch.LongTensor(idx_train_l)
        idx_test_l = torch.LongTensor(idx_test_l)


def load_data_432(task, t):
    embeddings = np.load("../data/node_embeddings/lmd_embedding_512_30.npy")
    label = np.load("../data/MD_matrix.npy")                        # 形状为(861, 253)
    label = np.hstack((label, np.zeros(shape=(861, 179))))          # 形状为(861, 432)

    if task == "lncRNA":
        # 处理 GCN的输入——邻接矩阵 adj_d
        adj_d = np.load("../data/correlation_matrix/P_d4_{}.npy".format(t))    # 注意：这里直接使用融合相关性与相似性的
        if adj_d.shape == (253, 253):
            adj_d = np.hstack((adj_d, np.zeros(shape=(253, 179))))
            adj_d = np.vstack((adj_d, np.zeros(shape=(179, 432))))
            for i in range(adj_d.shape[0]):
                adj_d[i][i] = 1
        print("adj_d.shape: ", adj_d.shape)  # (253, 253)

        # 处理 GCN的输入——节点特征向量 inp_d
        embeddings_d = embeddings[1298:1730, :]  # 作为GCN分类器的输入x
        # embeddings_d = embeddings[1298:1551, :]    # 作为GCN分类器的输入x
        print("embeddings_d.shape: ", embeddings_d.shape)           # (432, 128)

        # 处理 需要进行分类的 lncRNA 节点的特征向量 feature_l
        embeddings_l = embeddings[0:861, :]  # 由node2vec算法获取的lncRNA节点的特征，用于对lncRNA分类
        feature_l = embeddings_l
        print("feature_l.shape:", feature_l.shape)           # (861, 128)

        # 处理 lncRNA 节点的标签
        label_l = label
        print(label_l.shape)  # (861, 432)

        # 处理训练集、测试集
        lncRNA_n = 861
        train_n = int(lncRNA_n * 0.8)        # 训练集长度：688    测试集长度：173
        idx_train_l = range(0, train_n)      # range(0, 688)
        idx_test_l = range(train_n, 861)     # range(688, 861)

        # 将上述数据转换为 tensor类型
        label_l = torch.Tensor(label_l)
        feature_l = torch.FloatTensor(feature_l)
        # adj_d = torch.FloatTensor(adj_d)  #
        inp_d = torch.FloatTensor(embeddings_d)
        idx_train_l = torch.LongTensor(idx_train_l)
        idx_test_l = torch.LongTensor(idx_test_l)

        print(label_l.shape, feature_l.shape, adj_d.shape, inp_d.shape, idx_train_l.shape, idx_test_l.shape)
        return label_l, feature_l, adj_d, inp_d, idx_train_l, idx_test_l

    else:
        # 对疾病节点进行分类
        # 处理 GCN的输入——邻接矩阵 adj_d
        adj_d = np.load("../data/correlation_matrix/P_d1.npy")    # 注意：
        if adj_d.shape == (253, 253):
            adj_d = np.hstack((adj_d, np.zeros(shape=(253, 179))))
            adj_d = np.vstack((adj_d, np.zeros(shape=(179, 432))))
        print("adj_d.shape:", adj_d.shape)  # (432, 432)

        # 处理 GCN的输入——节点特征向量 inp_d
        embeddings_d = embeddings[1298:1730, :]  # 作为GCN分类器的输入x
        print(embeddings_d.shape)           # (432, 128)

        # 处理 需要进行分类的 lncRNA 节点的特征向量 feature_l
        embeddings_l = embeddings[0:861, :]  # 由node2vec算法获取的lncRNA节点的特征，用于对lncRNA分类
        feature_l = embeddings_l
        print("feature_l.shape:", feature_l.shape)           # (861, 128)

        # 处理 lncRNA 节点的标签
        label_l = label
        print(label_l.shape)  # (861, 432)

        # 处理训练集、测试集
        lncRNA_n = 861
        train_n = int(lncRNA_n * 0.8)        # 训练集长度：688    测试集长度：173
        idx_train_l = range(0, train_n)      # range(0, 688)
        idx_test_l = range(train_n, 861)     # range(688, 861)

        # 将上述数据转换为 tensor类型
        label_l = torch.FloatTensor(label_l)
        features_l = torch.FloatTensor(feature_l)
        adj_d = torch.FloatTensor(adj_d)  # 原adj_l为(240, 240)的 numpy.ndarray
        idx_train_l = torch.LongTensor(idx_train_l)
        idx_test_l = torch.LongTensor(idx_test_l)


"""多标签场景下的准确率计算"""
# 1. 基于样本的评估指标
# 1.1 准确率 accuracy
# 对于每个样本来说，准确率就是 TP 的标签数在整个 预测为正或真实为正 标签数中的占比
def Accuracy(y_true, y_pred):
    count = 0
    for i in range(y_true.shape[0]):
        p = sum(np.logical_and(y_true[i], y_pred[i]))  # 逻辑与   得到每个样本的TP的标签数
        q = sum(np.logical_or(y_true[i], y_pred[i]))  # 逻辑或   得到每个样本的 预测为正 或 真实为正 的标签数(TP+FN+FP)
        count += p / q  # 计算当前样本的准确率
    return count / y_true.shape[0]  # 返回所有样本上的均值


def ml_accuracy(y_pred, y_true, x, y):             # y_pred与 y_true 不支持浮点数
    y_pred = output2label(y_pred, x, y)            # 输入、输出都是tensor类型
    count = 0
    for i in range(y_true.shape[0]):
        p = torch.sum(y_true[i] & y_pred[i])  # 逻辑与   得到每个样本的 TP 的标签数
        q = torch.sum(y_true[i] | y_pred[i])  # 逻辑或   得到每个样本的 预测为正 或 真实为正 的标签数
        count += p / q
    return count / y_true.shape[0]


# 1.2 精准率 precision
# 对于每个样本来说，精确率就是 TP 的标签数在 TP+FP 的标签数中的占比
def Precision(y_true, y_pred):
    count = 0
    for i in range(y_true.shape[0]):
        if sum(y_pred[i]) == 0:  # 只考虑预测为正的情况
            continue
        count += sum(np.logical_and(y_true[i], y_pred[i])) / sum(y_pred[i])  # 计算出每个样本的精准率
    return count / y_true.shape[0]
# print(Precision(y_true, y_pred))  # 0.6666666666666666


def ml_Precision(y_true, y_pred):
    count = 0
    for i in range(y_true.shape[0]):
        if torch.sum(y_pred[i]) == 0:
            continue
        count += torch.sum(y_true[i] & y_pred[i]) / torch.sum(y_pred[i])
    return count / y_true.shape[0]


# 1.3 召回率 recall
# 对于每个样本来说，召回率就是 TP 的标签数在 TP+FN 的标签数中的占比
def Recall(y_true, y_pred):
    count = 0
    for i in range(y_true.shape[0]):
        if sum(y_true[i]) == 0:  # 只考虑真实标签为正的情况
            continue
        count += sum(np.logical_and(y_true[i], y_pred[i])) / sum(y_true[i])  # 计算每个样本的召回率
    return count / y_true.shape[0]
# print(Recall(y_true, y_pred))  # 0.611111111111111


def ml_Recall(y_true, y_pred):
    count = 0
    for i in range(y_true.shape[0]):
        if torch.sum(y_true[i]) == 0:  # 只考虑真实标签为正的情况
            continue
        count += torch.sum(y_true[i] & y_pred[i]) / torch.sum(y_true[i])  # 计算每个样本的召回率
    return count / y_true.shape[0]


# 1.4 F1值              先计算每个样本的F1值，再求平均
def F1measure(y_true, y_pred):
    count = 0
    for i in range(y_true.shape[0]):
        if sum(y_true[i]) == 0 and sum(y_pred[i]) == 0:
            continue
        p = sum(np.logical_and(y_true[i], y_pred[i]))
        q = sum(y_true[i]) + sum(y_pred[i])
        count += (2 * p) / q
    return count / y_true.shape[0]
# print(F1measure(y_true, y_pred))  # 0.6333333333333333


def ml_F1measure(y_true, y_pred):
    count = 0
    for i in range(y_true.shape[0]):
        if torch.sum(y_true[i]) == 0 and torch.sum(y_pred[i]) == 0:
            continue
        p = torch.sum(y_true[i] & y_pred[i])
        q = torch.sum(y_true[i]) + torch.sum(y_pred[i])
        count += (2 * p) / q
    return count / y_true.shape[0]


# 1.5 Hamming Loss
def Hamming_Loss(y_true, y_pred):
    count = 0
    for i in range(y_true.shape[0]):
        p = np.size(y_true[i] == y_pred[i])                # p为标签集的大小
        q = np.count_nonzero(y_true[i] == y_pred[i])       # q为该样本正确预测的标签的数量
        count += p - q                                     # count为该样本错误预测的标签的数量
    return count / (y_true.shape[0] * y_true.shape[-1])

# np.size()返回数组元素的个数
# np.count_nonzero()统计数组非零元素的个数

def ml_Hamming_Loss(y_true, y_pred):
    count = 0
    p = y_true.shape[1]
    for i in range(y_true.shape[0]):                # p为标签集的大小
        q = torch.sum(torch.tensor(y_true[i] == y_pred[i], dtype=torch.int32))       # q为该样本正确预测的标签的数量（TP+TN）
        count += p - q                                     # count为该样本错误预测的标签的数量
    return count / (y_true.shape[0] * y_true.shape[-1])


# 1.6 subset accuracy
# 计算完全预测正确的样本占总样本数的比例
def sub_accuracy(y_true, y_pred):
    count = 0
    for i in range(y_true.shape[0]):
        if np.array_equal(y_true[i], y_pred[i]):
            count += 1
    return count / y_true.shape[0]


def ml_sub_accuracy(y_true, y_pred):
    count = 0
    for i in range(y_true.shape[0]):
        if torch.equal(y_true[i], y_pred[i]):
            count += 1
    return count / y_true.shape[0]


"""评估指标"""
# 不考虑部分正确的情况
# （1）绝对匹配率      计算完全预测正确的样本占总样本数的比例
# print(accuracy_score(y_true, y_pred))  # 0.3333333333333333

# （2）0-1损失        计算完全预测错误的样本占总样本的比例
# print(zero_one_loss(y_true, y_pred))  # 0.6666666666666667








# 调用sklearn.metric中的方法计算precision recall f1_score
# 参数average="samples"的作用: 针对样本进行求平均操作
# print(precision_score(y_true=y_true, y_pred=y_pred, average="samples"))  # 0.6666666666666666
# print(recall_score(y_true=y_true, y_pred=y_pred, average="samples"))  # 0.611111111111111
# print(f1_score(y_true=y_true, y_pred=y_pred, average="samples"))  # 0.6333333333333333






# 2. 基于排序的评估指标
# 2.1 Coverage
def Coverage(logit, label):
    N = len(label)       # N表示样本的数量
    label_index = []
    for i in range(N):
        index = np.where(label[i] == 1.0)[0]
        label_index.append(index)
    cover = 0
    for i in range(N):
        # 从大到小排序
        index = np.argsort(-logit[i]).tolist()
        tmp = 0
        for item in label_index[i]:
            tmp = max(tmp, index.index(item) + 1)
        cover += tmp
    coverage = cover * 1.0 / N             # 在数据集上的平均覆盖率
    return coverage


# 2.2 One-Error
def One_error(label, logit):
    N = len(label)
    for i in range(N):
        if max(label[i]) == 0:
            print("该数据哪一类都不是")

    label_index = []                             # 存放 每个样本 label为1的标签的索引
    for i in range(N):
        index = np.where(label[i] == 1)[0]
        label_index.append(index)

    One_Error = 0
    for i in range(N):
        if np.argmax(logit[i]) not in label_index[i]:
            # np.argmax返回最大值元素对应的索引
            # 若预测结果的最大值的索引不在真实标签的索引中，则One_Error+1
            One_Error += 1
    One_Error = 1.0 * One_Error / N
    return One_Error


# 2.3 RankingLoss
def RankingLoss(label, logit):
    N = len(label)
    for i in range(N):
        if max(label[i]) == 0:
            print("该样本哪一类都不是")
        elif min(label[i]) == 1:
            print("该样本全都是")
    rankloss = 0
    for i in range(N):
        index1 = np.where(label[i] == 1)[0]    # 标签"1"的索引数组
        index0 = np.where(label[i] == 0)[0]    # 标签"0"的索引数组
        tmp = 0
        for j in index1:
            for k in index0:
                if logit[i][j] <= logit[i][k]:
                    tmp += 1
        rankloss += tmp / (len(index1) * len(index0))
    rankloss = rankloss / N
    return rankloss

# 2.4 Average_Precision
def Average_Precision(label, logit):
    N = len(label)
    for i in range(N):
        if max(label[i]) == 0:
            print("该样本哪一类都不是")
        elif min(label[i]) == 1:
            print("该样本每一类都是")
    precision = 0
    for i in range(N):
        index = np.where(label[i] == 1)[0]
        score = logit[i][index]
        score = sorted(score)
        score_all = sorted(logit[i])
        precision_tmp = 0
        for item in score:
            tmp1 = score.index(item)
            tmp1 = len(score) - tmp1
            tmp2 = score_all.index(item)
            tmp2 = len(score_all) - tmp2
            precision_tmp += tmp1 / tmp2
        precision += precision_tmp / len(score)
    average_precision = precision / N
    return average_precision



# 3. 基于标签的评估指标
# 3.1 micro
def micro_matrix(y_true, y_pred):
    y_true = y_true.flatten()
    y_pred = y_pred.flatten()
    TP, FP, TN, FN = 0, 0, 0, 0
    for i in range(len(y_true)):
        if y_true[i] == 1 and y_pred[i] == 1:
            TP += 1
        elif y_true[i] == 1 and y_pred[i] == 0:
            FN += 1
        elif y_true[i] == 0 and y_pred[i] == 1:
            FP += 1
        else:
            TN += 1
    assert TP + FP + TN + FN == y_true.shape[0]
    print(TP, FP, TN, FN)
    micro_accuracy = (TP + TN) / (TP + TN + FP + FN)
    micro_precision = TP / (TP + FP)
    micro_recall = TP / (TP + FN)
    micro_f1 = 2*micro_precision*micro_recall / (micro_precision+micro_recall)
    return micro_accuracy, micro_precision, micro_recall, micro_f1


def macro_matrix(y_true, y_pred):
    n_labels = y_true.shape[1]
    n_samples = y_true.shape[0]
    macro_accuracy = np.zeros(n_labels)
    macro_precision = np.zeros(n_labels)
    macro_recall = np.zeros(n_labels)
    macro_f1 = np.zeros(n_labels)
    for i in range(n_labels):

        TP, FP, TN, FN = 0, 0, 0, 0

        for j in range(n_samples):
            if y_true[j][i] == 1 and y_pred[j][i] == 1:
                TP += 1
            elif y_true[j][i] == 1 and y_pred[j][i] == 0:
                FN += 1
            elif y_true[j][i] == 0 and y_pred[j][i] == 1:
                FP += 1
            else:
                TN += 1
        assert TP + FP + TN + FN == len(y_true)

        macro_accuracy[i] = (TP + TN) / (TP + TN + FP + FN)
        macro_precision[i] = 0 if TP + FP == 0 else TP / (TP + FP)
        macro_recall[i] = 0 if TP + FN == 0 else TP / (TP + FN)
        macro_f1[i] = 0 if macro_precision[i] + macro_recall[i] == 0 else 2 * macro_precision[i] * macro_recall[i]/ (macro_precision[i] + macro_recall[i])
    return macro_accuracy.mean(), macro_precision.mean(), macro_recall.mean(), macro_f1.mean()

