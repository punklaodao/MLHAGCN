import numpy as np
import torch
from util import macro_matrix, micro_matrix


y_true = torch.tensor([[0, 1, 0, 1, 0],
                       [1, 1, 0, 0, 1],
                       [0, 0, 1, 1, 0],
                       [1, 1, 1, 0, 0]], dtype=torch.int32)

y_pred = torch.tensor([[0, 1, 1, 1, 0],
                       [1, 1, 0, 0, 1],
                       [0, 0, 0, 1, 0],
                       [1, 1, 1, 0, 0]], dtype=torch.int32)


def ml_sub_accuracy(y_true, y_pred):
    count = 0
    for i in range(y_true.shape[0]):
        if torch.equal(y_true[i], y_pred[i]):
            count += 1
    return count / y_true.shape[0]


print(ml_sub_accuracy(y_true, y_pred))

label = np.array([[0, 1, 0, 0, 1, 1],
                 [1, 0, 1, 1, 0, 1],
                 [0, 1, 1, 0, 0, 0]])
pred = np.array([[0, 1, 1, 0, 1, 0],
                [1, 0, 1, 1, 1, 1],
                [1, 1, 1, 0, 0, 1]])

micro_accuracy, micro_precision, micro_recall, micro_f1 = micro_matrix(label, pred)
print(micro_accuracy, micro_precision, micro_recall, micro_f1)
macro_accuracy, macro_precision, macro_recall, macro_f1 = macro_matrix(label, pred)
print(macro_accuracy, macro_precision, macro_recall, macro_f1)