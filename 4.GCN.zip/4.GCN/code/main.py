import argparse
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, zero_one_loss, precision_score, recall_score, f1_score, hamming_loss, \
    roc_curve, auc, precision_recall_curve

from util import *
from model import GCNwithNode2Vec


"""
对lncRNA分类，类别数为253, 样本数为861，标签形状为(861, 253)
训练集大小 int(861*0.8)=689
验证集大小 int(861*0.2)=172

训练GCN分类器，图中节点为疾病节点。
GCN的输入 节点特征x 形状为(253, input_size)
         邻接矩阵adj 形状为(253, 253)
"""

parser = argparse.ArgumentParser()
parser.add_argument('--no_cuda', action='store_true', default=False, help="Disables CUDA training.")
parser.add_argument('--fastmode', action='store_true', default=False, help="Validata during training pass.")
parser.add_argument('--seed', type=int, default=72, help="Random seed.")
parser.add_argument('--epochs', type=int, default=200, help="Number of epochs to train.")
parser.add_argument('--lr', type=float, default=0.005, help="Initial learning rate.")
parser.add_argument('--weight_decay', type=float, default=5e-4, help="Weight decay (L2 loss on parameters).")
parser.add_argument('--dropout', type=float, default=0.7, help='Dropout rate (1 - keep probability).')
# parser.add_argument('--alpha', type=float, default=0.2, help='Alpha for the leaky_relu.')
parser.add_argument('--embedding_dim', type=int, default=256, help="Embedding dimensions of node2vec.")
parser.add_argument('--t', type=int, default=0.8, help="The weight t between correlation and similarity matirx.")
parser.add_argument('--a', type=int, default=1.0, help="The threshold a to binary adj")
# parser.add_argument('--nclass_d', type=int, default=240, help="Number of classes of diseases.")
# parser.add_argument('--nclass_l', type=int, default=432, help="Number of classes of lncRNAs.")

args = parser.parse_args()
args.cuda = not args.no_cuda and torch.cuda.is_available()

# 设置随机数种子
random.seed(args.seed)
np.random.seed(args.seed)
torch.manual_seed(args.seed)
if args.cuda:
    torch.cuda.manual_seed(args.seed)

# 加载数据
labels_l, features_l, adj_d, inp_d, idx_train_l, idx_test_l = load_data("lncRNA", args.t)
# 形状
# labels_l     -> torch.Size([861, 253])
# features_l   -> torch.Size([861, 256])
# adj_d        -> torch.Size([253, 253])  !
# inp_d        -> torch.Size([253, 256])  !
# idx_train_l  -> torch.Size([688])
# idx_test_l   -> torch.Size([173])

label_weight = 0.1 * np.load("../data/label_sum.npy")
label_weight = torch.tensor(label_weight)

# 定义模型
model = GCNwithNode2Vec(num_classes=253, in_features=256, adj=adj_d, a=args.a)
# 定义优化器
optimizer = torch.optim.Adam(params=model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
# 定义损失函数
criterion = nn.MultiLabelSoftMarginLoss(weight=label_weight)

# 计算准确率的两个tensor张量
x = torch.ones(size=labels_l.size(), dtype=torch.int32)     # output值 >= 0.5，预测结果为 1，表示有关联
y = torch.zeros(size=labels_l.size(), dtype=torch.int32)    # output值 < 0.5，预测结果为 0，表示无关联

if args.cuda:
    model.cuda()
    # adj_d = adj_d.cuda()                      # GCN分类器的输入：adj
    inp_d = inp_d.cuda()
    features_l = features_l.cuda()             # 对lncRNA进行分类时使用的 lncRNA 的特征向量
    labels_l = labels_l.int().cuda()
    idx_train_l = idx_train_l.cuda()            # idx_train_l 是tensor类型的张量 且在cuda上
    idx_test_l = idx_test_l.cuda()

    criterion.cuda()

    x = x.cuda()
    y = y.cuda()


# 定义训练函数
def train(epoch):
    t = time.time()
    model.train()
    optimizer.zero_grad()
    output = model(features_l, inp_d)          # 形状：torch.Size([861, 432])
    train_loss = criterion(output[idx_train_l], labels_l[idx_train_l])   # loss是一个标量
    train_loss.backward()
    optimizer.step()

    # 评估指标
    train_acc = ml_accuracy(output[idx_train_l], labels_l[idx_train_l], x[idx_train_l], y[idx_train_l])
    # precision recall f1_score hamming_loss
    # 将label pred 索引 都转换为numpy数组

    y_pred = output2label(output, x, y)

    train_precision = ml_Precision(labels_l[idx_train_l], y_pred[idx_train_l])
    train_recall = ml_Recall(y_true=labels_l[idx_train_l], y_pred=y_pred[idx_train_l])
    train_f1 = ml_F1measure(y_true=labels_l[idx_train_l], y_pred=y_pred[idx_train_l])
    train_hamming = ml_Hamming_Loss(y_true=labels_l[idx_train_l], y_pred=y_pred[idx_train_l])
    train_subacc = ml_sub_accuracy(y_true=labels_l[idx_train_l], y_pred=y_pred[idx_train_l])

    if not args.fastmode:
        model.eval()
        output = model(features_l, inp_d)

    eval_loss = criterion(output[idx_test_l], labels_l[idx_test_l])
    eval_acc = ml_accuracy(output[idx_test_l], labels_l[idx_test_l], x[idx_test_l], y[idx_test_l])

    y_pred = output2label(output, x, y)

    val_precision = ml_Precision(y_true=labels_l[idx_test_l], y_pred=y_pred[idx_test_l])
    val_recall = ml_Recall(y_true=labels_l[idx_test_l], y_pred=y_pred[idx_test_l])
    val_f1 = ml_F1measure(y_true=labels_l[idx_test_l], y_pred=y_pred[idx_test_l])
    val_hamming = ml_Hamming_Loss(y_true=labels_l[idx_test_l], y_pred=y_pred[idx_test_l])
    val_subacc = ml_sub_accuracy(y_true=labels_l[idx_test_l], y_pred=y_pred[idx_test_l])

    print("Epoch: {:04d}".format(epoch + 1),
          "loss_train: {:.4f}".format(train_loss.item()),
          "acc_train: {:.4f}".format(train_acc.item()),
          "precision_train: {:.4f}".format(train_precision),
          "recall_train: {:.4f}".format(train_recall),
          "f1_train: {:.4f}".format(train_f1),
          "hamming_train: {:.4f}".format(train_hamming),
          "train_subacc: {:.4f}".format(train_subacc),

          "loss_val: {:.4f}".format(eval_loss.item()),
          "acc_val: {:.4f}".format(eval_acc.item()),
          "precision_val: {:.4f}".format(val_precision),
          "recall_val: {:.4f}".format(val_recall),
          "f1_val: {:.4f}".format(val_f1),
          "hamming_train: {:.4f}".format(val_hamming),
          "val_subacc: {:.4f}".format(val_subacc),


          "time: {:.4f}".format(time.time() - t))

    if epoch == args.epochs - 1:
        y_pred_binary = np.array(y_pred.cpu())
        output = output.detach().cpu().numpy()
        np.save("../results_thresholds/MLNVGCN_prediction_{}_{}_{}".format(args.embedding_dim, args.t, args.a), y_pred_binary)
        np.save("../results_thresholds/MLNVGCN_output_{}_{}_{}".format(args.embedding_dim, args.t, args.a), output)


# 训练模型
t_total = time.time()
for epoch in range(args.epochs):
    train(epoch)

print("Optimization Finished!")
print("Total time elapsed: {:.4f}s".format(time.time() - t_total))
