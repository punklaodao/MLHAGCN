import numpy as np
import torch
from gensim.models.keyedvectors import load_word2vec_format
from node2vec import Node2Vec

embedding_dimension = 64
walk_length = 30

path = "../embeddings/embedding_{}_{}.emb".format(embedding_dimension, walk_length)
embedding = load_word2vec_format(path)

print(embedding.get_vector(key="0"))

embedding_lmd = np.empty(shape=(1730, embedding_dimension))
for i in range(1730):
    embedding_lmd[i] = embedding.get_vector(str(i))
print(embedding_lmd)
print(embedding_lmd.shape)

# 保存 numpy.ndarray格式的embedding向量
save_path = "lmd_embedding_{}_{}".format(embedding_dimension, walk_length)
np.save(save_path, embedding_lmd)
