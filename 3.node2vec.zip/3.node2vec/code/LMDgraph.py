import os

import dgl
import networkx as nx
import numpy as np
import pandas as pd
import torch
from dgl import save_graphs, load_graphs


l = 861
m = 437
d = 432


# 构建LMD图，用于node2vec训练
# 分别为 l d m 节点 划分训练集、验证集、测试集大小
def train_mask():
    array = np.zeros(shape=(1730,), dtype=bool)
    array[0:603] = 1
    array[861:1167] = 1
    array[1298:1600] = 1
    return torch.tensor(array)


def val_mask():
    array = np.zeros(shape=(1730,), dtype=bool)
    array[603:775] = 1
    array[1167:1254] = 1
    array[1600:1686] = 1
    return torch.tensor(array)


def test_mask():
    array = np.zeros(shape=(1730,), dtype=bool)
    array[775:861] = 1
    array[1254:1298] = 1
    array[1686:1730] = 1
    return torch.tensor(array)


edge_file = pd.read_csv("../data/edge_no_sellfloop.csv", sep=",")
node1 = list(edge_file["node1"])
node2 = list(edge_file["node2"])

G = nx.Graph()
for i in range(len(node1)):
    u = node1[i]
    v = node2[i]
    G.add_edge(u, v)

print(G.number_of_nodes())  # 1730
print(G.number_of_edges())  # 115069

# 构建图
graph = dgl.from_networkx(G)
print(graph.number_of_nodes())   # 1730
print(graph.number_of_edges())   # 230138

# 划分掩码
graph.ndata['train_mask'] = train_mask()
graph.ndata['val_mask'] = val_mask()
graph.ndata['test_mask'] = test_mask()

print(graph)

# 节点的标签 (必须是整个图上的全部节点 计算loss时 提取出对应部分即可)
all_label = np.load("../data/all_label.npy")
all_label = torch.tensor(all_label, dtype=torch.int)  # torch.Size([1730, 1730])  dtype=torch.int32
graph.ndata['all_label'] = all_label

# 重排图
graph = dgl.reorder_graph(graph)

# 保存图
root = "../data"
name = "LMDgraph"
graph_path = os.path.join(root, name + '.bin')
save_graphs(str(graph_path), graph)

# # 从保存的路径加载图
# graphs, _ = load_graphs(str(graph_path))
# graph1 = graphs[0]
# print(graph1)
# print(graph1.ndata['feat'].shape)


