import dgl
import networkx as nx
from dgl import load_graphs
from node2vec import Node2Vec

# parameters
embedding_dimension = 64
walk_length = 30

# FILES
EMBEDDING_FILENAME = '../embeddings/embedding_{}_{}.emb'.format(embedding_dimension, walk_length)
EMBEDDING_MODEL_FILENAME = '../embedding_models/embedding_{}_{}.model'.format(embedding_dimension, walk_length)

# Create a graph
graph_path = "../data/LMDgraph.bin"
graphs, _ = load_graphs(graph_path)
graph = graphs[0]
graph = dgl.to_networkx(graph)

print(graph.number_of_nodes())   # 1730
print(graph.number_of_edges())   # 230138

# Precompute probabilities and generate walks
node2vec = Node2Vec(graph, dimensions=embedding_dimension, walk_length=walk_length, num_walks=200, workers=4)

# if d_graph is big enough to fit in the memory, pass temp_folder which has enough disk space
# Note: It will trigger "sharedmem" in Parallel, which will be slow on smaller graphs
# node2vec = Node2Vec(graph, dimensions=64, walk_length=30, num_walks=200, workers=4, temp_folder="/mnt/tmp_data")

# Embed
model = node2vec.fit(window=10, min_count=1, batch_words=4)
# Any keywords acceptable by gensim.Word2Vec can be passed, `dimensions` and `workers` are automatically passed (from the Node2Vec constructor)

# # Look for most similar nodes
# model.wv.most_similar('2')  # Output node names are always strings topn=10

# Save embeddings for later use
model.wv.save_word2vec_format(EMBEDDING_FILENAME)

# Save model for later use
model.save(EMBEDDING_MODEL_FILENAME)
